import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler 
from sklearn.ensemble import AdaBoostClassifier,RandomForestClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import confusion_matrix,accuracy_score,roc_auc_score,roc_curve
from sklearn.model_selection import RandomizedSearchCV
import numpy as np
from sklearn.model_selection import train_test_split as tts
from sklearn.metrics import classification_report
from yellowbrick.classifier import ClassificationReport
from sklearn.metrics import log_loss
from matplotlib import pyplot
from numpy import array
from sklearn import preprocessing
import matplotlib.pyplot as plt
import seaborn as sns
from xgboost import XGBClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import VotingClassifier
from mlxtend.feature_selection import SequentialFeatureSelector as SFS
from sklearn.feature_selection import SelectFromModel
from sklearn.feature_selection import f_classif
from sklearn.feature_selection import mutual_info_classif
from sklearn.feature_selection import SelectKBest,SelectPercentile
from mlxtend.classifier import StackingClassifier
from sklearn.externals import joblib
from sklearn.naive_bayes import GaussianNB

#GUI
from tkinter import *
from tkinter import messagebox
from openpyxl import load_workbook
import xlrd
import pandas as pd
from auto_tqdm import tqdm
from PIL import Image
from PIL import Image, ImageTk


df = pd.read_csv('oasis_longitudinal.csv')
print(df.head())

#Preprocessing

# df = df.loc[df['Visit']==1] # use first visit data only because of the analysis we're doing
df = df.reset_index(drop=True) # reset index after filtering first visit data
df['M/F'] = df['M/F'].replace(['F','M'], [0,1]) # M/F column
df['Group'] = df['Group'].replace(['Converted'], ['Demented']) # Target variable
df['Group'] = df['Group'].replace(['Demented', 'Nondemented'], [1,0]) # Target variable
df = df.drop(['MRI ID', 'Visit', 'Hand'], axis=1) # Drop unnecessary columns

def bar_chart(feature):
    Demented = df[df['Group']==1][feature].value_counts()
    Nondemented = df[df['Group']==0][feature].value_counts()
    df_bar = pd.DataFrame([Demented,Nondemented])
    df_bar.index = ['Demented','Nondemented']
    df_bar.plot(kind='bar',stacked=True, figsize=(8,5))

# Gender  and  Group ( Femal=0, Male=1)
bar_chart('M/F')
plt.xlabel('Group')
plt.ylabel('Number of patients')
plt.legend()
plt.title('Gender and Demented rate')
plt.show()


# Check missing values by each column
print(pd.isnull(df).sum())

# Removing rows with missing values
df_dropna = df.dropna(axis=0, how='any')
print(pd.isnull(df_dropna).sum())

print(df.head())
y = df_dropna['Group'].values # Target for the model
X = df_dropna[['M/F', 'Age', 'EDUC', 'SES', 'MMSE', 'eTIV', 'nWBV', 'ASF']] # Features we use

# sc = MinMaxScaler()
# training_set = sc.fit_transform(training_set)

col=['M/F', 'Age', 'EDUC', 'SES', 'MMSE', 'eTIV', 'nWBV', 'ASF']
X_train, X_test, y_train, y_test = tts(
    X,
    y,
    test_size=0.2,
    random_state=0)


##Mutual Information Gain
mi=mutual_info_classif(X_train,y_train)
mi=pd.Series(mi)
mi.index=X_train.columns
mi.sort_values(ascending=False)
mi.sort_values(ascending=False).plot.bar(figsize=(20,8))

sel_= SelectPercentile(mutual_info_classif,percentile=70).fit(X_train,y_train)
selected_feat_mutual_information=X_train.columns[sel_.get_support()]
print("Feature Selection method - Mutual Information Gain : ",selected_feat_mutual_information)

##univariate Analysis
univariate = f_classif(X_train,y_train)
univariate

univariate = pd.Series(univariate[1])
univariate.index=X_train.columns
univariate.sort_values(ascending=False,inplace=True)

univariate.sort_values(ascending=False).plot.bar(figsize=(20,8))

sel_ =SelectPercentile(f_classif,percentile=70).fit(X_train,y_train)
selected_feat_univariate=X_train.columns[sel_.get_support()]
print("Feature Selection Method - Univariate Analysis : ",selected_feat_univariate)


def plot_roc_curve(fpr, tpr):  
    plt.plot(fpr, tpr, color='orange', label='ROC')
    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC) Curve')
    plt.legend()
    plt.show()



def XGB(X_train,y_train,X_test,y_test):
  global y_pred_ada
  ada = XGBClassifier()
  ada.fit(X_train,y_train)
  print("XGBClassifier:train set")
  y_pred = ada.predict(X_train)
  pred=ada.predict_proba(X_test)   
  print("XGBClassifier:Confusion Matrix: ", confusion_matrix(y_train, y_pred))
  print ("XGBClassifier:Accuracy : ", accuracy_score(y_train,y_pred)*100)
  print("XGBClassifier:Test set")
  y_pred = ada.predict(X_test)
  y_pred_ada=y_pred
  print("XGBClassifier:Confusion Matrix: ", confusion_matrix(y_test, y_pred))
  print ("XGBClassifier:Accuracy : ", accuracy_score(y_test,y_pred)*100)
  #confusion Matrix
  matrix =confusion_matrix(y_test, y_pred)
  class_names=[0,1] 
  fig, ax = plt.subplots()
  tick_marks = np.arange(len(class_names))
  plt.xticks(tick_marks, class_names)
  plt.yticks(tick_marks, class_names)
  sns.heatmap(pd.DataFrame(matrix), annot=True, cmap="YlGnBu" ,fmt='g')
  ax.xaxis.set_label_position("top")
  plt.tight_layout()
  plt.title('Confusion matrix', y=1.1)
  plt.ylabel('Actual label')
  plt.xlabel('Predicted label')
  plt.show()
  #ROC_AUC curve
  global ada_fpr,ada_tpr
  probs = ada.predict_proba(X_test) 
  probs = probs[:, 1]  
  auc = roc_auc_score(y_test, probs)  
  print('AUC: %.2f' % auc)
  le = preprocessing.LabelEncoder()
  y_test1=le.fit_transform(y_test)
  ada_fpr, ada_tpr, thresholds = roc_curve(y_test1, probs)
  plot_roc_curve(ada_fpr, ada_tpr)
  #Classification Report
  target_names = ['Yes', 'No']
  prediction=ada.predict(X_test)
  print(classification_report(y_test, prediction, target_names=target_names))
  classes = ["Yes", "No"]
  visualizer = ClassificationReport(ada, classes=classes, support=True)
  visualizer.fit(X_train, y_train)  
  visualizer.score(X_test, y_test)  
  g = visualizer.poof()

XGB(X_train[selected_feat_mutual_information],y_train,X_test[selected_feat_mutual_information],y_test)




def GB(X_train,y_train,X_test,y_test):
  global y_pred_rf
  ada = GradientBoostingClassifier()
  ada.fit(X_train,y_train)
  print("Gradient Boosting:train set")
  y_pred = ada.predict(X_train)
  pred=ada.predict_proba(X_test)  
  print("Gradient Boosting:Confusion Matrix: ", confusion_matrix(y_train, y_pred))
  print ("Gradient Boosting:Accuracy : ", accuracy_score(y_train,y_pred)*100)
  print("Gradient Boosting:Test set")
  y_pred = ada.predict(X_test)
  y_pred_rf=y_pred 
  print("Gradient Boosting:Confusion Matrix: ", confusion_matrix(y_test, y_pred))
  print ("Gradient Boosting:Accuracy : ", accuracy_score(y_test,y_pred)*100)
  #confusion Matrix
  matrix =confusion_matrix(y_test, y_pred)
  class_names=[0,1] 
  fig, ax = plt.subplots()
  tick_marks = np.arange(len(class_names))
  plt.xticks(tick_marks, class_names)
  plt.yticks(tick_marks, class_names)
  sns.heatmap(pd.DataFrame(matrix), annot=True, cmap="YlGnBu" ,fmt='g')
  ax.xaxis.set_label_position("top")
  plt.tight_layout()
  plt.title('Confusion matrix', y=1.1)
  plt.ylabel('Actual label')
  plt.xlabel('Predicted label')
  plt.show()
  #ROC_AUC curve
  global rf_fpr,rf_tpr
  probs = ada.predict_proba(X_test) 
  probs = probs[:, 1]  
  auc = roc_auc_score(y_test, probs)  
  print('AUC: %.2f' % auc)
  le = preprocessing.LabelEncoder()
  y_test1=le.fit_transform(y_test)
  rf_fpr, rf_tpr, thresholds = roc_curve(y_test1, probs)
  plot_roc_curve(rf_fpr, rf_tpr)
  #Classification Report
  target_names = ['Yes', 'No']
  prediction=ada.predict(X_test)
  print(classification_report(y_test, prediction, target_names=target_names))
  classes = ["Yes", "No"]
  visualizer = ClassificationReport(ada, classes=classes, support=True)
  visualizer.fit(X_train, y_train)  
  visualizer.score(X_test, y_test)  
  g = visualizer.poof()

GB(X_train[selected_feat_mutual_information],y_train,X_test[selected_feat_mutual_information],y_test)


#KNN
def KNN(X_train,y_train,X_test,y_test):
  global y_pred_knn
  xgb=KNeighborsClassifier()
  xgb.fit(X_train,y_train)
  print("KNN:train set")
  y_pred = xgb.predict(X_train)
  pred=xgb.predict_proba(X_test)   
  print("KNN:Confusion Matrix: ", confusion_matrix(y_train, y_pred))
  print ("KNN:Accuracy : ", accuracy_score(y_train,y_pred)*100)
  print("KNN:Test set")
  y_pred = xgb.predict(X_test)
  y_pred_knn=y_pred
  print("KNN:Confusion Matrix: ", confusion_matrix(y_test, y_pred))
  print ("KNN:Accuracy : ", accuracy_score(y_test,y_pred)*100)
  #confusion Matrix
  matrix =confusion_matrix(y_test, y_pred)
  class_names=[0,1] 
  fig, ax = plt.subplots()
  tick_marks = np.arange(len(class_names))
  plt.xticks(tick_marks, class_names)
  plt.yticks(tick_marks, class_names)
  sns.heatmap(pd.DataFrame(matrix), annot=True, cmap="YlGnBu" ,fmt='g')
  ax.xaxis.set_label_position("top")
  plt.tight_layout()
  plt.title('Confusion matrix', y=1.1)
  plt.ylabel('Actual label')
  plt.xlabel('Predicted label')
  plt.show()
  #ROC_AUC curve
  global knn_fpr,knn_tpr
  probs = xgb.predict_proba(X_test) 
  probs = probs[:, 1]  
  auc = roc_auc_score(y_test, probs)  
  print('AUC: %.2f' % auc)
  le = preprocessing.LabelEncoder()
  y_test1=le.fit_transform(y_test)
  knn_fpr, knn_tpr, thresholds = roc_curve(y_test1, probs)
  plot_roc_curve(knn_fpr, knn_tpr)
  #Classification Report
  target_names = ['Yes', 'No']
  prediction=xgb.predict(X_test)
  print(classification_report(y_test, prediction, target_names=target_names))
  classes = ["Yes", "No"]
  visualizer = ClassificationReport(xgb, classes=classes, support=True)
  visualizer.fit(X_train, y_train)  
  visualizer.score(X_test, y_test)  
  g = visualizer.poof()

KNN(X_train[selected_feat_mutual_information],y_train,X_test[selected_feat_mutual_information],y_test)


#NB Classifier
def NB(X_train,y_train,X_test,y_test):
  global y_pred_nb
  vc = GaussianNB()  
  vc.fit(X_train,y_train)
  print("Naive Bayes :train set")
  y_pred = vc.predict(X_train)
  #pred=vc.predict_proba(X_test)   
  print("Naive Bayes :Confusion Matrix: ", confusion_matrix(y_train, y_pred))
  print ("Naive Bayes :Accuracy : ", accuracy_score(y_train,y_pred)*100)
  print("Naive Bayes :Test set")
  y_pred = vc.predict(X_test)
  y_pred_nb=y_pred
  print("Naive Bayes :Confusion Matrix: ", confusion_matrix(y_test, y_pred))
  print ("Naive Bayes :Accuracy : ", accuracy_score(y_test,y_pred)*100)
  #confusion Matrix
  matrix =confusion_matrix(y_test, y_pred)
  class_names=[0,1] 
  fig, ax = plt.subplots()
  tick_marks = np.arange(len(class_names))
  plt.xticks(tick_marks, class_names)
  plt.yticks(tick_marks, class_names)
  sns.heatmap(pd.DataFrame(matrix), annot=True, cmap="YlGnBu" ,fmt='g')
  ax.xaxis.set_label_position("top")
  plt.tight_layout()
  plt.title('Confusion matrix', y=1.1)
  plt.ylabel('Actual label')
  plt.xlabel('Predicted label')
  plt.show()
  #ROC_AUC curve
  global nb_fpr,nb_tpr
  probs = vc.predict_proba(X_test) 
  probs = probs[:, 1]  
  auc = roc_auc_score(y_test, probs)  
  print('AUC: %.2f' % auc)
  le = preprocessing.LabelEncoder()
  y_test1=le.fit_transform(y_test)
  nb_fpr, nb_tpr, thresholds = roc_curve(y_test1, probs)
  plot_roc_curve(nb_fpr, nb_tpr)
  #Classification Report
  target_names = ['Yes', 'No']
  prediction=vc.predict(X_test)
  print(classification_report(y_test, prediction, target_names=target_names))
  classes = ["Yes", "No"]
  visualizer = ClassificationReport(vc, classes=classes, support=True)
  visualizer.fit(X_train, y_train)  
  visualizer.score(X_test, y_test)  
  g = visualizer.poof()

NB(X_train[selected_feat_mutual_information],y_train,X_test[selected_feat_mutual_information],y_test)


# output_data=[1, 88, 14, 2.0, 30.0, 2004, 0.681, 0.876]
# output_data=pd.DataFrame([output_data],columns = col)
# ada = AdaBoostClassifier()
# ada.fit(X_train,y_train)
# pred=ada.predict(output_data)


def graph_roc_curve_multiple(ada_fpr, ada_tpr, rf_fpr, rf_tpr, knn_fpr, knn_tpr, nb_fpr, nb_tpr):
		          plt.figure(figsize=(16,8))
		          plt.title('ROC Curve \n Top 4 Classifiers', fontsize=18)
		          plt.plot(ada_fpr, ada_tpr, label='AdaBoost Classifier Score: {:.4f}'.format(roc_auc_score(y_test, y_pred_ada)))
		          plt.plot(rf_fpr, rf_tpr, label='Gradient Boosting Classifier Score: {:.4f}'.format(roc_auc_score(y_test, y_pred_rf)))
		          plt.plot(knn_fpr, knn_tpr, label='KNears Neighbors Classifier Score: {:.4f}'.format(roc_auc_score(y_test, y_pred_knn)))
		          plt.plot(nb_fpr, nb_tpr, label='Naive Bayes Classifier Score: {:.4f}'.format(roc_auc_score(y_test, y_pred_nb)))
		          plt.plot([0, 1], [0, 1], 'k--')
		          plt.axis([-0.01, 1, 0, 1])
		          plt.xlabel('False Positive Rate', fontsize=16)
		          plt.ylabel('True Positive Rate', fontsize=16)
		          plt.annotate('Minimum ROC Score of 50% \n (This is the minimum score to get)', xy=(0.5, 0.5), xytext=(0.6, 0.3),
		                      arrowprops=dict(facecolor='#6E726D', shrink=0.05),
		                      )
		          plt.legend()

graph_roc_curve_multiple(ada_fpr, ada_tpr, rf_fpr, rf_tpr, knn_fpr, knn_tpr, nb_fpr, nb_tpr)
plt.show()







root = Tk()  # Main window 
f = Frame(root)
frame1 = Frame(root)
frame2 = Frame(root)
frame3 = Frame(root)
root.title("Alzheimer Disease Prediction")
root.geometry("1080x730")

canvas = Canvas(width=1080, height=300)
canvas.pack()
filename=('Alzheimer’s_Hero.png')
load = Image.open(filename)
load = load.resize((1080, 300), Image.ANTIALIAS)
render = ImageTk.PhotoImage(load)
img = Label(image=render)
img.image = render
#photo = PhotoImage(file='landscape.png')
load = Image.open(filename)
img.place(x=1, y=1)
#canvas.create_image(-80, -80, image=img, anchor=NW)

root.configure(background='white')
scrollbar = Scrollbar(root)
scrollbar.pack(side=RIGHT, fill=Y)

firstname = StringVar()  # Declaration of all variables
lastname = StringVar()
id = StringVar()
dept = StringVar()
designation = StringVar()
remove_firstname = StringVar()
remove_lastname = StringVar()
searchfirstname = StringVar()
searchlastname = StringVar()
sheet_data = []
row_data = []





def add_entries():  # to append all data and add entries on click the button
    a = " "
    f = firstname.get()
    f1 = f.lower()
    l = lastname.get()
    l1 = l.lower()
    d = dept.get()
    d1 = d.lower()
    de = designation.get()
    de1 = de.lower()
    list1 = list(a)
    list1.append(f1)
    list1.append(l1)
    list1.append(d1)
    list1.append(de1)


def click( ):
    age =  float(e2.get())
    EDUC =  float(e3.get())
    SES =  float(e4.get())
    MMSE =  float(e5.get())
    eTIV =  float(e6.get())
    nWBV =  float(e7.get())
    ASF =  float(e8.get())
    gen  = designation.get()

    if(gen=="Male"):
        gen=1
    else:
        gen=0



    col = ['M/F', 'Age', 'EDUC', 'SES', 'MMSE', 'eTIV', 'nWBV', 'ASF']


    output_data=[]
    output_data.append(gen)
    output_data.append(age)
    output_data.append(EDUC)
    output_data.append(SES)
    output_data.append(MMSE)
    output_data.append(eTIV)
    output_data.append(nWBV)
    output_data.append(ASF)


    output_data=pd.DataFrame([output_data],columns = col)

    ada = XGBClassifier()
    ada.fit(X_train[selected_feat_mutual_information],y_train)

    pred=ada.predict(output_data[selected_feat_mutual_information])
    print("Prediction for Newly Added Data : ",pred)

    if(pred==1):
        e10.delete(0, END) #deletes the current value
        e10.insert(0, "Disease Detected")
    else:
        e10.delete(0, END) #deletes the current value
        e10.insert(0, "Normal")



def clear_all():  # for clearing the entry widgets
    frame1.pack_forget()
    frame2.pack_forget()
    frame3.pack_forget()




label1 = Label(root, text="Alzheimer Disease Prediction")
label1.config(font=('Italic', 18, 'bold'), justify=CENTER, background="Yellow", fg="Red", anchor="center")
#label1.pack(fill=X)



frame2.pack_forget()
frame3.pack_forget()
lab1 = Label(frame1, text="M/F: ", bg="red", fg="white")
lab1.grid(row=1, column=1, padx=10,pady=5)
designation.set("Select Option")
e1 = OptionMenu(frame1, designation, "Select Option", "Male", "Female")
e1.grid(row=1, column=2, padx=10,pady=5)



lab2 = Label(frame1, text="Age: ", bg="red", fg="white")
lab2.grid(row=2, column=1, padx=10,pady=5)
e2 = Entry(frame1 )
e2.grid(row=2, column=2, padx=10,pady=5)




lab3 = Label(frame1, text="EDUC: ", bg="red", fg="white")
lab3.grid(row=4, column=1, padx=10,pady=5)
e3 = Entry(frame1)
e3.grid(row=4, column=2, padx=10,pady=5)


lab4 = Label(frame1, text="SES: ", bg="red", fg="white")
lab4.grid(row=5, column=1, padx=10,pady=5)
e4 = Entry(frame1)
e4.grid(row=5, column=2, padx=10,pady=5)


lab5 = Label(frame1, text="MMSE: ", bg="red", fg="white")
lab5.grid(row=6, column=1, padx=10,pady=5)
e5 = Entry(frame1)
e5.grid(row=6, column=2, padx=10,pady=5)

lab6 = Label(frame1, text="eTIV: ", bg="red", fg="white")
lab6.grid(row=7, column=1, padx=10,pady=5)
e6 = Entry(frame1)
e6.grid(row=7, column=2, padx=10,pady=5)



lab7 = Label(frame1, text="nWBV:", bg="red", fg="white")
lab7.grid(row=9, column=1, padx=10,pady=5)
e7 = Entry(frame1)
e7.grid(row=9, column=2, padx=10,pady=5)


lab7 = Label(frame1, text="ASF:", bg="red", fg="white")
lab7.grid(row=10, column=1, padx=10,pady=5)
e8 = Entry(frame1)
e8.grid(row=10, column=2, padx=10,pady=5)



button5 = Button(frame1, text="Predict", command=click)
button5.grid(row=11, column=1)



output = Label(frame1, text="Output: ", bg="red", fg="white")
output.grid(row=12, column=1, padx=10,pady=5)
e10 = Entry(frame1)
e10.grid(row=12, column=2, padx=10,pady=5)

frame1.configure(background="Red")
frame1.pack(pady=5)


root.mainloop()
